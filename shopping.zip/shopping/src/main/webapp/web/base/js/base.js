	var form = layui.form;
	var $ = layui.jquery;
	var layer = layui.layer;
	var laytpl = layui.laytpl;
	var laypage = layui.laypage;
	var element=layui.element;
	
	function ajax(url, field, dataType, func) {
		$.ajax({
			url : "/shopping" + url,
			data : field,
			dataType : dataType,
			type : 'post',
			success : func
		});
	}
	//以当前jsp所在文件相对路径打开弹窗
	function openLayer(url, end) {
		layer.open({
			type : 2,
			area : [ '800px', '550px' ],
			fixed : false,
			maxmin : true,
			end : end,
			content : url
		})
	}
	//执行方法先问下
	function openConfirm(func, title) {
		layer.confirm(title ? title : "确定进行该操作？", {
			icon : 3,
			title : '提示'
		}, func);
	}
	function closeThis(){
		var index =parent.layer.getFrameIndex(window.name);
		parent.layer.close(index);
	}
	function getlaytpl(sel, data) {
		return laytpl($(sel).html()).render(data);
	}
	function setPageInfo(elem, count, curr, limit, jump) {
		laypage.render({
			elem : elem //分页容器的id
			,
			count : count //总页数
			,
			curr : curr//当前页
			,
			limit : limit//显示条数 
			,
			limits : [ 5, 10, 15, 20 ]
		    ,
			layout : [ 'count', 'prev', 'page', 'next', 'limit', 'refresh',
					'skip' ]
		    ,
			jump : jump
		});
	}