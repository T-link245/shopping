package com.st.ssm.shoppingcur.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.st.ssm.goods.model.GoodsImageModel;
import com.st.ssm.goods.model.GoodsModel;
import com.st.ssm.goods.service.IGoodsService;
import com.st.ssm.goods.service.impl.GoodsImageServiceImpl;
import com.st.ssm.order.model.OrderDetailModel;
import com.st.ssm.order.model.OrderModel;
import com.st.ssm.order.service.IOrderDetailService;
import com.st.ssm.order.service.IOrderService;
import com.st.ssm.shoppingcur.model.ShoppingCurModel;
import com.st.ssm.shoppingcur.service.IShoppingCurService;

@Controller
@RequestMapping("/shoppingCur")
public class ShoppingCurController {

	@Autowired
	private IShoppingCurService shoppingCurService;
	@Autowired
	private IGoodsService goodsService;
	@Autowired
	private GoodsImageServiceImpl goodsImageService;
	@Autowired
	private IOrderService orderService;
	@Autowired
	private IOrderDetailService orderDetailService;
	
	@ResponseBody
	@RequestMapping(value = "/insert",produces = "application/json; charset=utf-8")
	public String insert(ShoppingCurModel shoppingCurModel) {
		ShoppingCurModel model1 = shoppingCurService.selectModel(shoppingCurModel);
		int res = 0;
		if(model1==null)
		res = shoppingCurService.insert(shoppingCurModel);
		else {
			model1.setGoodsCountString(Integer.parseInt(model1.getGoodsCountString())+Integer.parseInt(shoppingCurModel.getGoodsCountString())+"");
			shoppingCurService.update(model1);
		}
		return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/addOrder",produces = "application/json; charset=utf-8")
	public String addOrder(String strings,String userCodeString,String sumPriceString) {
		String[] str = strings.split(",");
		int len = str.length;
		 SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
		 SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 String orderTimeString = df2.format(new Date());
         String orderCodeString = userCodeString+df.format(new Date());
         for(int i=0;i<len;i++) {
        	 int id = Integer.parseInt(str[i]);
        	 ShoppingCurModel shoppingCurModel = shoppingCurService.selectById(id);
        	 GoodsModel goodsModel = goodsService.selectId(shoppingCurModel.getGoodsCodeString());
        	 GoodsImageModel imageModel1 =new GoodsImageModel();
				imageModel1.setGoodsCodeString(goodsModel.getGoodsCodeString());
				imageModel1.setIsPrimaryString("true");
				List<GoodsImageModel> list = goodsImageService.selectList(imageModel1);
				String image = "";
				if(list.size()!=0)
					image = list.get(0).getUrlString();
        	 OrderDetailModel orderDetailModel = new OrderDetailModel(orderCodeString, goodsModel.getGoodsCodeString(), goodsModel.getGoodsNameString(),image, shoppingCurModel.getGoodsCountString(), goodsModel.getGoodsPriceString());
        	 orderDetailService.insert(orderDetailModel);
        	 shoppingCurService.delete(id);
         }
         OrderModel orderModel = new OrderModel(orderCodeString, userCodeString, "未设置", orderTimeString, sumPriceString, "no");
         orderService.insert(orderModel);

		return String.valueOf("1");
	}
	
	@ResponseBody
	@RequestMapping(value = "/directOrder",produces = "application/json; charset=utf-8")
	public String directOrder(String goodsCodeString,String userCodeString,String goodsCountString) {
		 SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
		 SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 String orderTimeString = df2.format(new Date());
         String orderCodeString = userCodeString+df.format(new Date());
         GoodsModel goodsModel = goodsService.selectId(goodsCodeString);
         GoodsImageModel imageModel1 =new GoodsImageModel();
			imageModel1.setGoodsCodeString(goodsModel.getGoodsCodeString());
			imageModel1.setIsPrimaryString("true");
			List<GoodsImageModel> list = goodsImageService.selectList(imageModel1);
			String image = "";
			if(list.size()!=0)
				image = list.get(0).getUrlString();
         OrderDetailModel orderDetailModel = new OrderDetailModel(orderCodeString, goodsModel.getGoodsCodeString(), goodsModel.getGoodsNameString(),image, goodsCountString, goodsModel.getGoodsPriceString());
         orderDetailService.insert(orderDetailModel);
         String sumPriceString = Integer.parseInt(goodsModel.getGoodsPriceString())*Integer.parseInt(goodsCountString)+"";
         OrderModel orderModel = new OrderModel(orderCodeString, userCodeString, "未设置", orderTimeString, sumPriceString, "no");
         orderService.insert(orderModel);
		return String.valueOf("1");
	}
	
	@ResponseBody
	@RequestMapping(value = "/update",produces = "application/json; charset=utf-8")
	public String update(ShoppingCurModel shoppingCurModel) {
		    int res = shoppingCurService.update(shoppingCurModel);
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/delete",produces = "application/json; charset=utf-8")
	public String delete(ShoppingCurModel shoppingCurModel) {
		    int res = shoppingCurService.delete(shoppingCurModel.getId());
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectByUser",produces = "application/json; charset=utf-8")
	public String selectAll(ShoppingCurModel shoppingCurModel) {
		List<ShoppingCurModel> list = new ArrayList<ShoppingCurModel>();
		list = shoppingCurService.selectList(shoppingCurModel.getUserCodeString());
		int count = shoppingCurService.selectCount(shoppingCurModel);
		JSONArray jsonArray = new JSONArray();
		for (ShoppingCurModel model2 : list) {
			JSONObject object =new JSONObject();
			String goodsCodeString=model2.getGoodsCodeString();
			GoodsModel goodsModel = goodsService.selectId(goodsCodeString);
			object.put("id", model2.getId());
			object.put("goodsNameString", goodsModel.getGoodsNameString());
			object.put("goodsPriceString", Integer.parseInt(goodsModel.getGoodsPriceString()));
			object.put("goodsCountString", Integer.parseInt(model2.getGoodsCountString()));
			GoodsImageModel model1 = new GoodsImageModel();
			model1.setIsPrimaryString("true");
			model1.setGoodsCodeString(goodsCodeString);
			List<GoodsImageModel> list2 = goodsImageService.selectList(model1);
			if(list2.size()!=0)
			    object.put("image", list2.get(0).getUrlString());
			else 
				object.put("image", "");
			object.put("count", count);
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}
}
