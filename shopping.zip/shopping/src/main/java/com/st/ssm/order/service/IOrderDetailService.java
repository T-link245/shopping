package com.st.ssm.order.service;

import java.util.List;

import com.st.ssm.order.model.OrderDetailModel;

public interface IOrderDetailService {

	int insert(OrderDetailModel orderModel);

	int update(OrderDetailModel orderModel);

	List<OrderDetailModel> selectList(OrderDetailModel orderModel);

	OrderDetailModel selectId(String orderCodeString);

	int selectCount(OrderDetailModel orderModel);

	int delete(Integer id);

	int deleteList(OrderDetailModel orderDetailModel);

}
