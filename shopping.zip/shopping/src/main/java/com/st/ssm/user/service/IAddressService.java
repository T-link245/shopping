package com.st.ssm.user.service;

import java.util.List;

import com.st.ssm.user.model.AddressModel;

public interface IAddressService {
	int insert(AddressModel model);

	List<AddressModel> selectList(AddressModel model);

	int selectCount(AddressModel model);

	AddressModel selectId(int id);

	int update(AddressModel model);

	int delete(int id);

}
