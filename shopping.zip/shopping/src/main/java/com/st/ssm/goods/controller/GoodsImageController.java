package com.st.ssm.goods.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.st.ssm.goods.model.GoodsImageModel;
import com.st.ssm.goods.service.IGoodsImageService;

@Controller
@RequestMapping("/goodsImage")
public class GoodsImageController {
	@Autowired
	private IGoodsImageService goodsImageService;
	
	@ResponseBody
	@RequestMapping(value = "/upload",produces = "application/json; charset=utf-8")
    public String fileUpload(HttpServletRequest request,HttpServletResponse response,String code){  
        JSONObject object = new JSONObject();
        object.put("code", 1);
        long startTime=System.currentTimeMillis();   //获取开始时间  
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());  
        if(multipartResolver.isMultipart(request)){ //判断request是否有文件上传  
            MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest)request;  
            Iterator<String> ite = multiRequest.getFileNames();  
            while(ite.hasNext()){  
                MultipartFile file = multiRequest.getFile(ite.next());  
                if(file!=null){
                    File localFile = new File("D:/DxOffice/workspace/image/"+file.getOriginalFilename());  
                    try {
                    	if(!localFile.exists())//判断图片是否存在
                        file.transferTo(localFile); //将上传文件写到服务器上指定的文件  
                        GoodsImageModel model =new GoodsImageModel();
                        model.setUrlString(file.getOriginalFilename());
                        model.setGoodsCodeString(code);
                        model.setTypeString("png");
                        model.setIsPrimaryString("false");
                        goodsImageService.insert(model);
                        object.put("code", 0);
                    } catch (IllegalStateException e) {  
                        e.printStackTrace();  
                    } catch (IOException e) {  
                        e.printStackTrace();  
                    }
                }  
            }  
        }  
        long endTime=System.currentTimeMillis(); //获取结束时间  
        System.out.println("上传文件共使用时间："+(endTime-startTime));  
        return object.toString();  
    }
	
	@RequestMapping(value = "/insert",produces = "application/json; charset=utf-8")
	public String insert(GoodsImageModel goodsImageModel) {
		int res = goodsImageService.insert(goodsImageModel);
		return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/update",produces = "application/json; charset=utf-8")
	public String update(GoodsImageModel goodsImageModel) {
		    int res = goodsImageService.update(goodsImageModel);
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/delete",produces = "application/json; charset=utf-8")
	public String delete(GoodsImageModel goodsImageModel) {
		    GoodsImageModel model = goodsImageService.selectId(goodsImageModel.getId());
		    int res = goodsImageService.delete(goodsImageModel.getId());
		    new File("D:\\DxOffice\\workspace\\image\\"+model.getUrlString()).delete(); 
			return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/prime",produces = "application/json; charset=utf-8")
	public String prime(GoodsImageModel goodsImageModel) {
		String goodsCodeString = goodsImageService.selectId(goodsImageModel.getId()).getGoodsCodeString();
		GoodsImageModel model1 =new GoodsImageModel();
		model1.setGoodsCodeString(goodsCodeString);
		model1.setIsPrimaryString("true");
		GoodsImageModel model = goodsImageService.selectList(model1).get(0);
		model.setIsPrimaryString("false");
		goodsImageService.updateActive(model);
		goodsImageModel.setIsPrimaryString("true");
		int res = goodsImageService.updateActive(goodsImageModel);
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectAll",produces = "application/json; charset=utf-8")
	public String selectAll(GoodsImageModel goodsImageModel) {
		List<GoodsImageModel> list = new ArrayList<GoodsImageModel>();
		list = goodsImageService.selectList(goodsImageModel);	
		JSONArray jsonArray = new JSONArray();
		for (GoodsImageModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("id", model2.getId());
			object.put("image", model2.getUrlString());
			object.put("count", goodsImageService.selectCount(goodsImageModel));
			jsonArray.put(object);
		}
		System.out.println(jsonArray.toString());
		return jsonArray.toString();
	}
}
