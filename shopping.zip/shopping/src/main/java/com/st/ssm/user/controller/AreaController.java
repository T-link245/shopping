package com.st.ssm.user.controller;

public class AreaController {

}
