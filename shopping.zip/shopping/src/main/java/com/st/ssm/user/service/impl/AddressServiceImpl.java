package com.st.ssm.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.user.mapper.AddressMapper;
import com.st.ssm.user.model.AddressModel;
import com.st.ssm.user.service.IAddressService;
@Service
public class AddressServiceImpl implements IAddressService{

	@Autowired(required=false)
	public AddressMapper mapper;
	@Override
	public int insert(AddressModel model) {
		// TODO Auto-generated method stub
		return mapper.insert(model);
	}

	@Override
	public List<AddressModel> selectList(AddressModel model) {
		// TODO Auto-generated method stub
		return mapper.selectAll(model);
	}

	@Override
	public int selectCount(AddressModel model) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public AddressModel selectId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int update(AddressModel model) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
