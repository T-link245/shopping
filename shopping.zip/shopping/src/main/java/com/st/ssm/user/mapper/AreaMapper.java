package com.st.ssm.user.mapper;

public interface AreaMapper {

}
