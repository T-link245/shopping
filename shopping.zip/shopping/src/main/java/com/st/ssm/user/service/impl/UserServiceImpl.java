package com.st.ssm.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.user.mapper.UserMapper;
import com.st.ssm.user.model.UserModel;
import com.st.ssm.user.service.IUserService;
import com.st.ssm.util.MD5;

@Service
public class UserServiceImpl implements IUserService{
	
	@Autowired(required=false)
	public UserMapper mapper;
	
	@Override
	public int insert(UserModel userModel) {
		// TODO Auto-generated method stub
		if(mapper.selectId(userModel.getUserCodeString())==null) {
			userModel.setUserPasswordString(MD5.encode(userModel.getUserPasswordString()));
			return mapper.insert(userModel);
		}
		return 0;
	}

	@Override
	public List<UserModel> selectList(UserModel userModel) {
		// TODO Auto-generated method stub
		userModel.setUserCodeString("%"+userModel.getUserCodeString()+"%");
		userModel.setUserNameString("%"+userModel.getUserNameString()+"%");
		return mapper.selectAll(userModel);
	}
	
	@Override
	public UserModel selectId(String userCodeString) {
		// TODO Auto-generated method stub
		return mapper.selectId(userCodeString);
	}

	@Override
	public int selectCount(UserModel userModel) {
		// TODO Auto-generated method stub
		return mapper.selectCount(userModel);
	}

	@Override
	public int update(UserModel userModel) {
		// TODO Auto-generated method stub
		return mapper.update(userModel);
	}

	@Override
	public int updatePassword(String userCodeString, String password2) {
		// TODO Auto-generated method stub
		UserModel model = new UserModel();
		model.setUserCodeString(userCodeString);
		model.setUserPasswordString(MD5.encode(password2));
		return mapper.updateActive(model);
	}

	@Override
	public int delete(String userCodeString) {
		// TODO Auto-generated method stub
		return mapper.delete(userCodeString);
	}
}
