package com.st.ssm.kinds.service;

import java.util.List;

import com.st.ssm.kinds.model.KindsModel;

public interface IKindsService {

	int insert(KindsModel kindsModel);

	int update(KindsModel kindsModel);

	List<KindsModel> selectList(KindsModel kindsModel);

	KindsModel selectId(String kindsCodeString);

	int delete(String code);

	int selectCount(KindsModel kindsModel);
	
	KindsModel selectModel(KindsModel kindsModel);

	List<KindsModel> selectParent(String parentCodeString);

	KindsModel selectByName(String parentNameString);
}
