package com.st.ssm.goods.model;

import com.st.ssm.util.PubPage;

public class GoodsModel extends PubPage{
	private String goodsCodeString;
	private String goodsNameString;
	private String goodsInventoryString;
	private String goodsCostString;
	private String goodsPriceString;
	private String goodsDescriptionString;
	private String kindsCodeString;
	public String getGoodsCodeString() {
		return goodsCodeString;
	}
	public void setGoodsCodeString(String goodsCodeString) {
		this.goodsCodeString = goodsCodeString;
	}
	public String getGoodsNameString() {
		return goodsNameString;
	}
	public void setGoodsNameString(String goodsNameString) {
		this.goodsNameString = goodsNameString;
	}
	public String getGoodsInventoryString() {
		return goodsInventoryString;
	}
	public void setGoodsInventoryString(String goodsInventoryString) {
		this.goodsInventoryString = goodsInventoryString;
	}
	public String getGoodsCostString() {
		return goodsCostString;
	}
	public void setGoodsCostString(String goodsCostString) {
		this.goodsCostString = goodsCostString;
	}
	public String getGoodsPriceString() {
		return goodsPriceString;
	}
	public void setGoodsPriceString(String goodsPriceString) {
		this.goodsPriceString = goodsPriceString;
	}
	public String getGoodsDescriptionString() {
		return goodsDescriptionString;
	}
	public void setGoodsDescriptionString(String goodsDescriptionString) {
		this.goodsDescriptionString = goodsDescriptionString;
	}
	public String getKindsCodeString() {
		return kindsCodeString;
	}
	public void setKindsCodeString(String kindsCodeString) {
		this.kindsCodeString = kindsCodeString;
	}
	
}
