package com.st.ssm.user.mapper;

import java.util.List;

import com.st.ssm.user.model.AddressModel;

public interface AddressMapper {
	int insert(AddressModel t);
	
	int delete(Object id);
	
	int update(AddressModel t);
	
	int updateActive(AddressModel t);
	
	AddressModel selectId(Object id);
	
	List<AddressModel> selectAll(AddressModel t);
	
	int selectCount(AddressModel t);
}
