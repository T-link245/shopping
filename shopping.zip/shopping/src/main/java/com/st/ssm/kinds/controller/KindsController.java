package com.st.ssm.kinds.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.st.ssm.kinds.model.KindsModel;
import com.st.ssm.kinds.service.IKindsService;

@Controller
@RequestMapping("/kinds")
public class KindsController {
	@Autowired
	private IKindsService kindsService;

	@RequestMapping(value = "/insert", produces = "application/json; charset=utf-8")
	public String insert(KindsModel kindsModel) {
		int res = kindsService.insert(kindsModel);
		return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/update", produces = "application/json; charset=utf-8")
	public String update(KindsModel kindsModel) {
		int res = kindsService.update(kindsModel);
		return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/delete", produces = "application/json; charset=utf-8")
	public String delete(KindsModel kindsModel, Model model) {
		int res = kindsService.delete(kindsModel.getKindsCodeString());
		return String.valueOf(res);
	}

	// 进行品种链表的查询，查询条件是（品种的名称模糊查询，品种的上级种类名进行精准查询）
	@ResponseBody
	@RequestMapping(value = "/selectAll", produces = "application/json; charset=utf-8")
	public String selectAll(KindsModel kindsModel, String parentNameString) {
		List<KindsModel> list = new ArrayList<KindsModel>();
		//如果数据库不存在输入的品种上级名称将不作为查询条件
		if (parentNameString != null && parentNameString.length() != 0) {
			KindsModel kindsModel1 = kindsService.selectByName(parentNameString);
			if(kindsModel1!=null) {
			String parentCodeString = kindsModel1.getKindsCodeString();
			kindsModel.setParentCodeString(parentCodeString);	
			}
		}
		list = kindsService.selectList(kindsModel);
		String parentName = "";
		JSONArray jsonArray = new JSONArray();
		for (KindsModel model2 : list) {
			JSONObject object = new JSONObject();
			object.put("kindsCodeString", model2.getKindsCodeString());
			object.put("kindsNameString", model2.getKindsNameString());
			object.put("kindsDescriptionString", model2.getKindsDescriptionString());
			// 当parentCodeString不为空且长度不为0时，返回parentCodeString对应的parentNameString
			parentName = (model2.getParentCodeString() == null || model2.getParentCodeString().length() == 0) ? ""
					: kindsService.selectId(model2.getParentCodeString()).getKindsNameString();
			object.put("parentNameString", parentName);
			object.put("count", kindsService.selectCount(kindsModel));
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectMenu", produces = "application/json; charset=utf-8")
	public String selectMenu() {
		List<KindsModel> list = new ArrayList<KindsModel>();
		list = kindsService.selectParent("002");
		JSONArray jsonArray = new JSONArray();
		for (KindsModel model : list) {
			JSONArray jsonArray2 = new JSONArray();
			JSONObject object = new JSONObject();
			object.put("oneNameString", model.getKindsNameString());
			List<KindsModel> list2 = new ArrayList<KindsModel>();
			list2 = kindsService.selectParent(model.getKindsCodeString());
			for (KindsModel model2 : list2) {
				JSONObject object2 = new JSONObject();
				object2.put("kindsCodeString", model2.getKindsCodeString());
				object2.put("kindsNameString", model2.getKindsNameString());
				jsonArray2.put(object2);
			}
			object.put("array", jsonArray2);
			jsonArray.put(object);
		}
		System.out.println(jsonArray.toString());
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectAllKinds", produces = "application/json; charset=utf-8")
	public String selectAllKinds(KindsModel kindsModel) {
		List<KindsModel> list = new ArrayList<KindsModel>();
		list = kindsService.selectList(kindsModel);
//		model.addAttribute("list", list);
		JSONArray jsonArray = new JSONArray();
		for (KindsModel model2 : list) {
			JSONObject object = new JSONObject();
			object.put("parentCodeString", model2.getKindsCodeString());
			object.put("parentNameString", model2.getKindsNameString());
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}

	@ResponseBody
	@RequestMapping(value = "/selectByParent", produces = "application/json; charset=utf-8")
	public String selectByParent(KindsModel kindsModel) {
		List<KindsModel> list = new ArrayList<KindsModel>();
		list = kindsService.selectList(kindsModel);
		JSONArray jsonArray = new JSONArray();
		for (KindsModel model2 : list) {
			JSONObject object = new JSONObject();
			object.put("code", model2.getKindsCodeString());
			object.put("name", model2.getKindsNameString());
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}

	@ResponseBody
	@RequestMapping(value = "/selectId", produces = "application/json; charset=utf-8")
	public String selectId(KindsModel kindsModel) {
		JSONArray jsonArray = new JSONArray();
		String parentNameString = "";
		KindsModel model2 = kindsService.selectId(kindsModel.getKindsCodeString());
		JSONObject object = new JSONObject();
		object.put("kindsCodeString", model2.getKindsCodeString());
		object.put("kindsNameString", model2.getKindsNameString());
		object.put("kindsDescriptionString", model2.getKindsDescriptionString());
		parentNameString = (model2.getParentCodeString() == null || model2.getParentCodeString().length() == 0) ? ""
				: kindsService.selectId(model2.getParentCodeString()).getKindsNameString();
		object.put("parentNameString", parentNameString);
		jsonArray.put(object);
		return jsonArray.toString();
	}

}