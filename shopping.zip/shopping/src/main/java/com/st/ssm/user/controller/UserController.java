package com.st.ssm.user.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.omg.CORBA.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.st.ssm.user.model.UserModel;
import com.st.ssm.user.service.IUserService;
import com.st.ssm.util.MD5;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private IUserService userService;
	
	@ResponseBody
	@RequestMapping(value = "/add",produces = "application/json; charset=utf-8")
	public String add(UserModel userModel) {
		int res = userService.insert(userModel);
		return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/register",produces = "application/json; charset=utf-8")
	public String register(UserModel userModel) {
		int res = userService.insert(userModel);
		return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/login",produces = "application/json; charset=utf-8")
	public String login(UserModel userModel,HttpServletRequest request) {
		UserModel userModel2 = new UserModel();
		userModel2 = userService.selectId(userModel.getUserCodeString());
		if(userModel2!=null&&userModel2.getUserPasswordString().equals(MD5.encode(userModel.getUserPasswordString()))) {
			request.getSession().setAttribute("userCode",userModel2.getUserCodeString());
			request.getSession().setAttribute("userName",userModel2.getUserNameString());
			return "1";
		}
		return "0";
	}
	@ResponseBody
	@RequestMapping(value = "/goLogout",produces = "application/json; charset=utf-8")
	public String goLogout(UserModel userModel,HttpServletRequest request,HttpServletResponse response) {
		request.getSession().removeAttribute("userName");
		request.getSession().removeAttribute("userCode");
		try {
			response.sendRedirect(request.getContextPath() + "/web/page/user/login.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "0";
	}
	@ResponseBody
	@RequestMapping(value = "/goLogout2",produces = "application/json; charset=utf-8")
	public String goLogout2(UserModel userModel,HttpServletRequest request,HttpServletResponse response) {
		request.getSession().removeAttribute("userName");
		request.getSession().removeAttribute("userCode");
		try {
			response.sendRedirect(request.getContextPath() + "/web/page/login.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "0";
	}

	
	@ResponseBody
	@RequestMapping(value = "/update",produces = "application/json; charset=utf-8")
	public String update(UserModel userModel) {
		    int res = userService.update(userModel);
			return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/updPassword",produces = "application/json; charset=utf-8")
	public String updPassword(String userCodeString,String password1,String password2,String password3) {
		    UserModel model = userService.selectId(userCodeString);
		    if(!model.getUserPasswordString().equals(MD5.encode(password1))||!password2.equals(password3))
		    	return "0";
		    int res = userService.updatePassword(userCodeString,password2);
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/delete",produces = "application/json; charset=utf-8")
	public String delete(UserModel userModel,Model model) {
		    int res = userService.delete(userModel.getUserCodeString());
		    model.addAttribute("user", userModel);
			model.addAttribute("msg", "删除成功");
			return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/selectAll",produces = "application/json; charset=utf-8")
	public String selectAll(UserModel userModel,Model model) {
		List<UserModel> list = new ArrayList<UserModel>();
		list = userService.selectList(userModel);	
//		model.addAttribute("list", list);
		JSONArray jsonArray = new JSONArray();
		for (UserModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("userCodeString", model2.getUserCodeString());
			object.put("userNameString", model2.getUserNameString());
			object.put("userPhoneString", model2.getUserPhoneString());
			object.put("userSexString", model2.getUserSexString());
			object.put("count", userService.selectCount(userModel));
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}

	@ResponseBody
	@RequestMapping(value = "/selectId",produces = "application/json; charset=utf-8")
	public String selectId(UserModel userModel,Model model) {
		JSONArray jsonArray = new JSONArray();
		UserModel model2 = userService.selectId(userModel.getUserCodeString());
			JSONObject object =new JSONObject();
			object.put("userCodeString", model2.getUserCodeString());
			object.put("userNameString", model2.getUserNameString());
			object.put("userPhoneString", model2.getUserPhoneString());
			object.put("userSexString", model2.getUserSexString());
			jsonArray.put(object);		
		return jsonArray.toString();
	}
	
}