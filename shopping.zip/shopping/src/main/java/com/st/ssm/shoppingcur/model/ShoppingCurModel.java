package com.st.ssm.shoppingcur.model;

import com.st.ssm.util.PubPage;

public class ShoppingCurModel extends PubPage{
	private Integer id;
	private String userCodeString;
	private String goodsCodeString;
	private String goodsCountString;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserCodeString() {
		return userCodeString;
	}
	public void setUserCodeString(String userCodeString) {
		this.userCodeString = userCodeString;
	}
	public String getGoodsCodeString() {
		return goodsCodeString;
	}
	public void setGoodsCodeString(String goodsCodeString) {
		this.goodsCodeString = goodsCodeString;
	}
	public String getGoodsCountString() {
		return goodsCountString;
	}
	public void setGoodsCountString(String goodsCountString) {
		this.goodsCountString = goodsCountString;
	}
	
}
