package com.st.ssm.goods.model;

import com.st.ssm.util.PubPage;

public class GoodsImageModel extends PubPage{
	private Integer id;
	private String goodsCodeString;
	private String urlString;
	private String typeString;
	private String isPrimaryString;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGoodsCodeString() {
		return goodsCodeString;
	}
	public void setGoodsCodeString(String goodsCodeString) {
		this.goodsCodeString = goodsCodeString;
	}
	public String getUrlString() {
		return urlString;
	}
	public void setUrlString(String urlString) {
		this.urlString = urlString;
	}
	public String getTypeString() {
		return typeString;
	}
	public void setTypeString(String typeString) {
		this.typeString = typeString;
	}
	public String getIsPrimaryString() {
		return isPrimaryString;
	}
	public void setIsPrimaryString(String isPrimaryString) {
		this.isPrimaryString = isPrimaryString;
	}
	
}
