package com.st.ssm.kinds.service.impl;

import java.util.List;

import org.apache.ibatis.jdbc.Null;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.kinds.mapper.KindsMapper;
import com.st.ssm.kinds.model.KindsModel;
import com.st.ssm.kinds.service.IKindsService;

@Service
public class KindsServiceImpl implements IKindsService{

	@Autowired(required=false)
	public KindsMapper mapper;
	
	@Override
	public int insert(KindsModel kindsModel) {
		// TODO Auto-generated method stub
		if((mapper.selectId(kindsModel.getKindsCodeString())==null))
		return mapper.insert(kindsModel);
		return 0;
	}

	@Override
	public int update(KindsModel kindsModel) {
		// TODO Auto-generated method stub
		return mapper.update(kindsModel);
	}

	@Override
	public int delete(String kindsCodeString) {
		// TODO Auto-generated method stub
		return mapper.delete(kindsCodeString);
	}

	@Override
	public int selectCount(KindsModel kindsModel) {
		// TODO Auto-generated method stub
		return mapper.selectCount(kindsModel);
	}
	
	@Override
	public List<KindsModel> selectList(KindsModel kindsModel) {
		// TODO Auto-generated method stub
		if(kindsModel.getKindsNameString()!=null)
		    kindsModel.setKindsNameString("%"+kindsModel.getKindsNameString()+"%");
		return mapper.selectAll(kindsModel);
	}

	@Override
	public KindsModel selectId(String kindsCodeString) {
		// TODO Auto-generated method stub
		if(kindsCodeString==null||kindsCodeString.length()==0)
			return new KindsModel();
		return mapper.selectId(kindsCodeString);
	}


	@Override
	public KindsModel selectModel(KindsModel kindsModel) {
		// TODO Auto-generated method stub
		return mapper.selectModel(kindsModel);
	}

	@Override
	public List<KindsModel> selectParent(String parentCodeString) {
		// TODO Auto-generated method stub
		return mapper.selectParent(parentCodeString);
	}

	@Override
	public KindsModel selectByName(String kindsNameString) {
		// TODO Auto-generated method stub
		return mapper.selectByName(kindsNameString);
	}




}
