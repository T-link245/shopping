package com.st.ssm.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.order.mapper.OrderDetailMapper;
import com.st.ssm.order.model.OrderDetailModel;
import com.st.ssm.order.service.IOrderDetailService;

@Service
public class OrderDetailServiceImpl implements IOrderDetailService{

	@Autowired(required=false)
	public OrderDetailMapper mapper;
	
	@Override
	public int insert(OrderDetailModel orderModel) {
		// TODO Auto-generated method stub
			return mapper.insert(orderModel);
	}

	@Override
	public int update(OrderDetailModel orderModel) {
		// TODO Auto-generated method stub
		return mapper.update(orderModel);
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return mapper.delete(id);
	}

	@Override
	public List<OrderDetailModel> selectList(OrderDetailModel orderModel) {
		// TODO Auto-generated method stub
		return mapper.selectAll(orderModel);
	}
	
	@Override
	public int selectCount(OrderDetailModel orderModel) {
		// TODO Auto-generated method stub
		return mapper.selectCount(orderModel);
	}

	@Override
	public OrderDetailModel selectId(String orderCodeString) {
		// TODO Auto-generated method stub
		return mapper.selectId(orderCodeString);
	}

	@Override
	public int deleteList(OrderDetailModel orderDetailModel) {
		// TODO Auto-generated method stub
		return mapper.deleteModel(orderDetailModel);
	}

}