package com.st.ssm.order.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.st.ssm.order.model.OrderDetailModel;
import com.st.ssm.order.model.OrderModel;
import com.st.ssm.order.service.IOrderDetailService;
import com.st.ssm.order.service.IOrderService;

@Controller
@RequestMapping("/orderDetail")
public class OrderDetailController{
	@Autowired
	private IOrderDetailService orderDetailService;
	
	@RequestMapping(value = "/insert",produces = "application/json; charset=utf-8")
	public String insert(OrderDetailModel orderDetailModel) {
		int res = orderDetailService.insert(orderDetailModel);
		return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/update",produces = "application/json; charset=utf-8")
	public String update(OrderDetailModel orderDetailModel) {
		    int res = orderDetailService.update(orderDetailModel);
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/delete",produces = "application/json; charset=utf-8")
	public String delete(OrderDetailModel orderDetailModel) {
		    int res = orderDetailService.delete(orderDetailModel.getId());
			return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/selectAll",produces = "application/json; charset=utf-8")
	public String selectAll(OrderDetailModel orderDetailModel) {
		List<OrderDetailModel> list = new ArrayList<OrderDetailModel>();
		list = orderDetailService.selectList(orderDetailModel);	
		JSONArray jsonArray = new JSONArray();
		for (OrderDetailModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("id", model2.getId());
			object.put("goodsCodeString", model2.getGoodsCodeString());
			object.put("goodsNameString", model2.getGoodsNameString());
			object.put("imageString", model2.getImageString());
			object.put("countString", model2.getCountString());
			object.put("priceString", model2.getPriceString());
			object.put("count", orderDetailService.selectCount(orderDetailModel));
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectParent",produces = "application/json; charset=utf-8")
	public String selectParent(OrderDetailModel orderDetailModel) {
		List<OrderDetailModel> list = new ArrayList<OrderDetailModel>();
		list = orderDetailService.selectList(orderDetailModel);	
//		model.addAttribute("list", list);
		JSONArray jsonArray = new JSONArray();
		for (OrderDetailModel model2 : list) {
			JSONObject object =new JSONObject();
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}

	@ResponseBody
	@RequestMapping(value = "/selectId",produces = "application/json; charset=utf-8")
	public String selectId(OrderDetailModel orderDetailModel) {
		JSONArray jsonArray = new JSONArray();
		String parentNameString = "";
			JSONObject object =new JSONObject();
			object.put("parentNameString", parentNameString);
			jsonArray.put(object);		
		return jsonArray.toString();
	}
	

}	
