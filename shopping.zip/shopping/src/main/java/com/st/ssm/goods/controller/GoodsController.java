package com.st.ssm.goods.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.st.ssm.goods.model.GoodsImageModel;
import com.st.ssm.goods.model.GoodsModel;
import com.st.ssm.goods.service.IGoodsImageService;
import com.st.ssm.goods.service.IGoodsService;
import com.st.ssm.kinds.model.KindsModel;
import com.st.ssm.kinds.service.IKindsService;

@Controller
@RequestMapping("/goods")
public class GoodsController{
	@Autowired
	private IGoodsService goodsService;
	@Autowired
	private IKindsService kindsService;
	@Autowired
	private IGoodsImageService goodsImageService;
	
	@RequestMapping(value = "/insert",produces = "application/json; charset=utf-8")
	public String insert(GoodsModel goodsModel) {
		int res = goodsService.insert(goodsModel);
		return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/update",produces = "application/json; charset=utf-8")
	public String update(GoodsModel goodsModel) {
		    int res = goodsService.update(goodsModel);
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/delete",produces = "application/json; charset=utf-8")
	public String delete(GoodsModel goodsModel) {
		    int res = goodsService.delete(goodsModel.getGoodsCodeString());
			return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/selectAll",produces = "application/json; charset=utf-8")
	public String selectAll(GoodsModel goodsModel) {
		List<GoodsModel> list = new ArrayList<GoodsModel>();
		list = goodsService.selectList(goodsModel);	
		String kindsNameString = "";
		JSONArray jsonArray = new JSONArray();
		for (GoodsModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("goodsCodeString", model2.getGoodsCodeString());
			object.put("goodsNameString", model2.getGoodsNameString());
			object.put("goodsDescriptionString", model2.getGoodsDescriptionString());
			//当kindsCodeString不为空且长度不为0时，返回kindsCodeString对应的kindsNameString
			kindsNameString = (model2.getKindsCodeString()==null||model2.getKindsCodeString().length()==0)?"":kindsService.selectId(model2.getKindsCodeString()).getKindsNameString();
			object.put("kindsNameString", kindsNameString);
			object.put("count", goodsService.selectCount(goodsModel));
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectParent",produces = "application/json; charset=utf-8")
	public String selectParent(GoodsModel goodsModel) {
		List<GoodsModel> list = new ArrayList<GoodsModel>();
		list = goodsService.selectList(goodsModel);	
//		model.addAttribute("list", list);
		JSONArray jsonArray = new JSONArray();
		for (GoodsModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("parentCodeString", model2.getGoodsCodeString());
			object.put("parentNameString", model2.getGoodsNameString());
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}

	@ResponseBody
	@RequestMapping(value = "/selectId",produces = "application/json; charset=utf-8")
	public String selectId(String goodsCodeString) {
		JSONArray jsonArray = new JSONArray();
		String level1 = "";
		String level2 = "";
		String parentNameString = "";
		GoodsModel model2 = goodsService.selectId(goodsCodeString);
			JSONObject object =new JSONObject();
			object.put("goodsCodeString", model2.getGoodsCodeString());
			object.put("goodsNameString", model2.getGoodsNameString());
			object.put("goodsDescriptionString", model2.getGoodsDescriptionString());
			System.out.println(level1);
			level2 = kindsService.selectId(model2.getKindsCodeString()).getParentCodeString();
			level1 = kindsService.selectId(level2).getParentCodeString();
			String level2Name = (level2==null||level2.length()==0)?"":kindsService.selectId(level2).getKindsNameString();
			String level1Name = (level1==null||level1.length()==0)?"":kindsService.selectId(level1).getKindsNameString();
			object.put("level1",level1Name);
			object.put("level2",level2Name);
			parentNameString = kindsService.selectId(model2.getKindsCodeString()).getKindsNameString();
			object.put("level3", parentNameString);
			jsonArray.put(object);
			
			List<KindsModel> list = new ArrayList<KindsModel>();
			JSONArray jsonArray1 = null;
			
			jsonArray1 = new JSONArray();
			list = kindsService.selectParent("001");
			for (KindsModel model : list) {
				JSONObject object1 =new JSONObject();
				object1.put("code", model.getKindsCodeString());
				object1.put("name", model.getKindsNameString());
				jsonArray1.put(object1);
			}
			jsonArray.put(jsonArray1);
			
			jsonArray1 =  new JSONArray();
			list = kindsService.selectParent(level1);
			for (KindsModel model : list) {
				JSONObject object1 =new JSONObject();
				object1.put("code", model.getKindsCodeString());
				object1.put("name", model.getKindsNameString());
				jsonArray1.put(object1);
			}
			jsonArray.put(jsonArray1);
			
			jsonArray1 = new JSONArray();
			list = kindsService.selectParent(level2);
			for (KindsModel model : list) {
				JSONObject object1 =new JSONObject();
				object1.put("code", model.getKindsCodeString());
				object1.put("name", model.getKindsNameString());
				jsonArray1.put(object1);
			}
			jsonArray.put(jsonArray1);
		
			System.out.println(jsonArray.toString());
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectIdq",produces = "application/json; charset=utf-8")
	public String selectIdq(String goodsCodeString) {
		    GoodsModel model2 = goodsService.selectId(goodsCodeString);
			JSONObject object =new JSONObject();
			object.put("code", model2.getGoodsCodeString());
			object.put("name", model2.getGoodsNameString());
			object.put("description", model2.getGoodsDescriptionString());
			GoodsImageModel imageModel1 =new GoodsImageModel();
			imageModel1.setGoodsCodeString(goodsCodeString);
			imageModel1.setIsPrimaryString("true");
			List<GoodsImageModel> list = goodsImageService.selectList(imageModel1);
			if(list.size()!=0)
			    object.put("image", list.get(0).getUrlString());
			else 
				object.put("image", "");
			object.put("price", model2.getGoodsPriceString());
		return object.toString();
	}
	
	//返回菜单显示的商品信息
	@ResponseBody
	@RequestMapping(value = "/selectMenu", produces = "application/json; charset=utf-8")
	public String selectMenu(GoodsModel goodsModel2) {
		List<KindsModel> list = new ArrayList<KindsModel>();
		list = kindsService.selectParent("002");
		JSONArray jsonArray = new JSONArray();
		//找到二级菜单：电脑，手机...
		for (KindsModel model : list) {
			List<KindsModel> list2 = new ArrayList<KindsModel>();
			list2 = kindsService.selectParent(model.getKindsCodeString());
			//找到三级菜单：华为手机，vivo手机...
			for (KindsModel model2 : list2) {
				GoodsModel goodsModel = new GoodsModel();
				goodsModel.setKindsCodeString(model2.getKindsCodeString());
				List<GoodsModel> list3 = new ArrayList<GoodsModel>();
				list3 = goodsService.selectList(goodsModel);
				JSONObject object1 = new JSONObject();
				JSONArray jsonArray2 = new JSONArray();
				//找的每个三级菜单对应的所有商品
				for (GoodsModel model3 : list3) {
					JSONObject object2 = new JSONObject();
					object2.put("code", model3.getGoodsCodeString());
					object2.put("name", model3.getGoodsNameString());
					object2.put("description", model3.getGoodsDescriptionString());
					GoodsImageModel imageModel1 =new GoodsImageModel();
					imageModel1.setGoodsCodeString(model3.getGoodsCodeString());
					imageModel1.setIsPrimaryString("true");
					List<GoodsImageModel> list4 = goodsImageService.selectList(imageModel1);
					if(list4.size()!=0)
						object2.put("image", list4.get(0).getUrlString());
					else 
						object2.put("image", "");
					object2.put("price", model3.getGoodsPriceString());
					jsonArray2.put(object2);
				}
				object1.put("kindsCodeString", model2.getKindsCodeString());
				object1.put("array", jsonArray2);
				jsonArray.put(object1);
			}
		}
		System.out.println(jsonArray.toString());
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectByModel",produces = "application/json; charset=utf-8")
	public String selectByKinds(GoodsModel goodsModel) {
		System.out.println(goodsModel.getKindsCodeString());
		List<GoodsModel> list = new ArrayList<GoodsModel>();
		list = goodsService.selectList(goodsModel);	
		JSONArray jsonArray = new JSONArray();
		for (GoodsModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("code", model2.getGoodsCodeString());
			object.put("name", model2.getGoodsNameString());
			object.put("descr", model2.getGoodsDescriptionString());
			object.put("price",  model2.getGoodsPriceString());
			GoodsImageModel imageModel1 =new GoodsImageModel();
			imageModel1.setGoodsCodeString(model2.getGoodsCodeString());
			imageModel1.setIsPrimaryString("true");
			List<GoodsImageModel> list2 = goodsImageService.selectList(imageModel1);
			if(list2.size()!=0)
			    object.put("image", list2.get(0).getUrlString());
			else 
				object.put("image", "");
			object.put("count", goodsService.selectCount(goodsModel));
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}
	
}