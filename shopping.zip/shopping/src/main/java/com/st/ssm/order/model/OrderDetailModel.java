package com.st.ssm.order.model;

import com.st.ssm.util.PubPage;

public class OrderDetailModel extends PubPage{
	private Integer id;
	private String orderCodeString;
	private String goodsCodeString;
	private String goodsNameString;
	private String imageString;
	//总数
	private String countString;
	//总价
	private String priceString;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getOrderCodeString() {
		return orderCodeString;
	}
	public void setOrderCodeString(String orderCodeString) {
		this.orderCodeString = orderCodeString;
	}
	public String getGoodsCodeString() {
		return goodsCodeString;
	}
	public void setGoodsCodeString(String goodsCodeString) {
		this.goodsCodeString = goodsCodeString;
	}
	public String getGoodsNameString() {
		return goodsNameString;
	}
	public void setGoodsNameString(String goodsNameString) {
		this.goodsNameString = goodsNameString;
	}
	public String getImageString() {
		return imageString;
	}
	public void setImageString(String imageString) {
		this.imageString = imageString;
	}
	public String getCountString() {
		return countString;
	}
	public void setCountString(String countString) {
		this.countString = countString;
	}
	public String getPriceString() {
		return priceString;
	}
	public void setPriceString(String priceString) {
		this.priceString = priceString;
	}
	public OrderDetailModel(String orderCodeString, String goodsCodeString, String goodsNameString,
			String imageString, String countString, String priceString) {
		super();
		this.orderCodeString = orderCodeString;
		this.goodsCodeString = goodsCodeString;
		this.goodsNameString = goodsNameString;
		this.imageString = imageString;
		this.countString = countString;
		this.priceString = priceString;
	}
	public OrderDetailModel() {
		super();
	}
	
}
