package com.st.ssm.goods.mapper;

import java.util.List;

import com.st.ssm.goods.model.GoodsImageModel;

public interface GoodsImageMapper {
	int insert(GoodsImageModel t);
	
	int delete(Object id);
	
	int update(GoodsImageModel t);
	
	int updateActive(GoodsImageModel t);
	
	GoodsImageModel selectId(Object id);
	
	List<GoodsImageModel> selectAll(GoodsImageModel t);
	
	int selectCount(GoodsImageModel t);
}
