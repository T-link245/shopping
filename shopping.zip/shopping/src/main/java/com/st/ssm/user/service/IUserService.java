package com.st.ssm.user.service;

import java.util.List;

import org.springframework.ui.Model;

import com.st.ssm.user.model.UserModel;

public interface IUserService {

	int insert(UserModel userModel);

	List<UserModel> selectList(UserModel userModel);

	int selectCount(UserModel userModel);

	UserModel selectId(String userCodeString);

	int update(UserModel userModel);

	int delete(String userCodeString);

	int updatePassword(String userCodeString, String password2);

}
