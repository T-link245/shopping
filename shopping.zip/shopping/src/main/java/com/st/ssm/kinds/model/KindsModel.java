package com.st.ssm.kinds.model;

import com.st.ssm.util.PubPage;

public class KindsModel extends PubPage{
	private String kindsCodeString;
	private String kindsNameString;
	private String parentCodeString;
	private String kindsDescriptionString;
	public String getKindsCodeString() {
		return kindsCodeString;
	}
	public void setKindsCodeString(String kindsCodeString) {
		this.kindsCodeString = kindsCodeString;
	}
	public String getKindsNameString() {
		return kindsNameString;
	}
	public void setKindsNameString(String kindsNameString) {
		this.kindsNameString = kindsNameString;
	}
	public String getParentCodeString() {
		return parentCodeString;
	}
	public void setParentCodeString(String parentCodeString) {
		this.parentCodeString = parentCodeString;
	}
	public String getKindsDescriptionString() {
		return kindsDescriptionString;
	}
	public void setKindsDescriptionString(String kindsDescriptionString) {
		this.kindsDescriptionString = kindsDescriptionString;
	}
	
}
