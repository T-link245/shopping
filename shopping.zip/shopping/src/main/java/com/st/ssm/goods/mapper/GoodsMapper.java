package com.st.ssm.goods.mapper;

import java.util.List;

import com.st.ssm.goods.model.GoodsModel;

public interface GoodsMapper {
	int insert(GoodsModel t);
	
	int delete(Object id);
	
	int update(GoodsModel t);
	
	int updateActive(GoodsModel t);
	
	GoodsModel selectId(Object id);
	
	List<GoodsModel> selectAll(GoodsModel t);
	
	int selectCount(GoodsModel t);
}
