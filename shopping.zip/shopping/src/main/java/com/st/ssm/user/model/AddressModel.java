package com.st.ssm.user.model;

import com.st.ssm.util.PubPage;

public class AddressModel extends PubPage{
private String userCodeString;
private String addressString;
private Integer id;
public String getUserCodeString() {
	return userCodeString;
}
public void setUserCodeString(String userCodeString) {
	this.userCodeString = userCodeString;
}
public String getAddressString() {
	return addressString;
}
public void setAddressString(String addressString) {
	this.addressString = addressString;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}

}
