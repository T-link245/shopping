package com.st.ssm.shoppingcur.service;

import java.util.Collection;
import java.util.List;

import com.st.ssm.goods.model.GoodsModel;
import com.st.ssm.shoppingcur.model.ShoppingCurModel;

public interface IShoppingCurService {

	int insert(ShoppingCurModel shoppingCurModel);

	int update(ShoppingCurModel shoppingCurModel);

	int delete(Integer id);

	List<ShoppingCurModel> selectList(String userCodeString);

	int selectCount(ShoppingCurModel shoppingCurModel);

	ShoppingCurModel selectById(Integer id);

	ShoppingCurModel selectModel(ShoppingCurModel shoppingCurModel);

}
