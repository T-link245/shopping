package com.st.ssm.order.service;

import java.util.Collection;
import java.util.List;

import com.st.ssm.order.model.OrderModel;

public interface IOrderService {
	int insert(OrderModel orderModel);

	int update(OrderModel orderModel);

	List<OrderModel> selectList(OrderModel orderModel);

	OrderModel selectId(String orderCodeString);

	int delete(String code);

	int selectCount(OrderModel orderModel);

	int updateActive(OrderModel model);


}
