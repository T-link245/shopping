package com.st.ssm.order.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.st.ssm.order.model.OrderDetailModel;
import com.st.ssm.order.model.OrderModel;
import com.st.ssm.order.service.IOrderService;

@Controller
@RequestMapping("/order")
public class OrderController{
	@Autowired
	private IOrderService orderService;
	
	@ResponseBody
	@RequestMapping(value = "/insert",produces = "application/json; charset=utf-8")
	public String insert(OrderModel orderModel) {
		int res = orderService.insert(orderModel);
		return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/update",produces = "application/json; charset=utf-8")
	public String update(OrderModel orderModel) {
		    int res = orderService.update(orderModel);
			return String.valueOf(res);
	}
	
	@ResponseBody
	@RequestMapping(value = "/delete",produces = "application/json; charset=utf-8")
	public String delete(OrderModel orderModel) {
		    int res = orderService.delete(orderModel.getOrderCodeString());
			return String.valueOf(res);
	}

	@ResponseBody
	@RequestMapping(value = "/selectOrderList",produces = "application/json; charset=utf-8")
	public String selectOrderList(OrderModel orderModel) {
		List<OrderModel> list = new ArrayList<OrderModel>();
		list = orderService.selectList(orderModel);
		JSONArray jsonArray = new JSONArray();
		for (OrderModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("orderCodeString", model2.getOrderCodeString());
			object.put("sumPrice", model2.getSumPriceString());
			object.put("address", model2.getAddressString());
			object.put("time", model2.getOrderTimeString());
			object.put("state", model2.getIsPaymentString());
			object.put("count", orderService.selectCount(orderModel));
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectAll",produces = "application/json; charset=utf-8")
	public String selectAll(OrderModel orderModel) {
		List<OrderModel> list = new ArrayList<OrderModel>();
		list = orderService.selectList(orderModel);	
		JSONArray jsonArray = new JSONArray();
		for (OrderModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("orderCodeString", model2.getOrderCodeString());
			object.put("userCodeString", model2.getUserCodeString());
			object.put("address", model2.getAddressString());
			object.put("count", orderService.selectCount(orderModel));
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectParent",produces = "application/json; charset=utf-8")
	public String selectParent(OrderModel orderModel) {
		List<OrderModel> list = new ArrayList<OrderModel>();
		list = orderService.selectList(orderModel);	
//		model.addAttribute("list", list);
		JSONArray jsonArray = new JSONArray();
		for (OrderModel model2 : list) {
			JSONObject object =new JSONObject();
			object.put("parentCodeString", model2.getOrderCodeString());
			jsonArray.put(object);
		}
		return jsonArray.toString();
	}

	@ResponseBody
	@RequestMapping(value = "/selectId",produces = "application/json; charset=utf-8")
	public String selectId(OrderModel orderModel) {
		JSONArray jsonArray = new JSONArray();
		String parentNameString = "";
		OrderModel model2 = orderService.selectId(orderModel.getOrderCodeString());
			JSONObject object =new JSONObject();
			object.put("userCodeString", model2.getUserCodeString());
			object.put("addressString", model2.getAddressString());
			object.put("orderCodeString", model2.getOrderCodeString());
			object.put("isPaymentString", model2.getIsPaymentString());
			object.put("parentNameString", parentNameString);
			jsonArray.put(object);		
		return jsonArray.toString();
	}
	
	@ResponseBody
	@RequestMapping(value = "/pay",produces = "application/json; charset=utf-8")
	public String pay(OrderDetailModel orderDetailModel,String addressString) {
		OrderModel model = new OrderModel();
		model.setOrderCodeString(orderDetailModel.getOrderCodeString());
		model.setIsPaymentString("yes");
		model.setAddressString(addressString);
		int res = orderService.updateActive(model);
		return String.valueOf(res);
	}
}