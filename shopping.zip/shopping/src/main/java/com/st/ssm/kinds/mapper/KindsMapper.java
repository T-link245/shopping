package com.st.ssm.kinds.mapper;

import java.util.List;

import com.st.ssm.kinds.model.KindsModel;

public interface KindsMapper {

	int insert(KindsModel t);
	
	int delete(Object id);
	
	int update(KindsModel t);
	
	int updateActive(KindsModel t);
	
	KindsModel selectId(Object id);
	
	List<KindsModel> selectAll(KindsModel t);
	
	int selectCount(KindsModel t);

	KindsModel selectModel(KindsModel kindsModel);

	List<KindsModel> selectParent(String parentCodeString);

	KindsModel selectByName(String kindsNameString);
}
