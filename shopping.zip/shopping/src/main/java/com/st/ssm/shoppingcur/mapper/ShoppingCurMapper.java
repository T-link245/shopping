package com.st.ssm.shoppingcur.mapper;

import java.util.List;

import com.st.ssm.shoppingcur.model.ShoppingCurModel;

public interface ShoppingCurMapper {

	int insert(ShoppingCurModel t);
	
	int delete(Object id);
	
	int update(ShoppingCurModel t);
	
	int updateActive(ShoppingCurModel t);
	
	ShoppingCurModel selectId(Object id);
	
	List<ShoppingCurModel> selectAll(ShoppingCurModel t);
	
	int selectCount(ShoppingCurModel t);

	ShoppingCurModel selectModel(ShoppingCurModel shoppingCurModel);
}
