package com.st.ssm.user.model;

import com.st.ssm.util.PubPage;

public class UserModel extends PubPage{
	private String userCodeString;
    private String userNameString;
    private String userPasswordString;
    private String userPhoneString;
    private String userEmailString;
    private String userSexString;
    private String userAgeString;
    
	public UserModel() {
		super();
	}
	public String getUserCodeString() {
		return userCodeString;
	}
	public void setUserCodeString(String userCodeString) {
		this.userCodeString = userCodeString;
	}
	public String getUserNameString() {
		return userNameString;
	}
	public void setUserNameString(String userNameString) {
		this.userNameString = userNameString;
	}
	public String getUserPasswordString() {
		return userPasswordString;
	}
	public void setUserPasswordString(String userPasswordString) {
		this.userPasswordString = userPasswordString;
	}
	public String getUserPhoneString() {
		return userPhoneString;
	}
	public void setUserPhoneString(String userPhoneString) {
		this.userPhoneString = userPhoneString;
	}
	public String getUserEmailString() {
		return userEmailString;
	}
	public void setUserEmailString(String userEmailString) {
		this.userEmailString = userEmailString;
	}
	public String getUserSexString() {
		return userSexString;
	}
	public void setUserSexString(String userSexString) {
		this.userSexString = userSexString;
	}
	public String getUserAgeString() {
		return userAgeString;
	}
	public void setUserAgeString(String userAgeString) {
		this.userAgeString = userAgeString;
	}
	@Override
	public String toString() {
		return "UserModel [userCodeString=" + userCodeString + ", userNameString=" + userNameString
				+ ", userPasswordString=" + userPasswordString + ", userPhoneString=" + userPhoneString
				+ ", userEmailString=" + userEmailString + ", userSexString=" + userSexString + ", userAgeString="
				+ userAgeString + ", getCount()=" + getCount() + ", getPageIndex()=" + getPageIndex()
				+ ", getPageLimit()=" + getPageLimit() + ", getRowStart()=" + getRowStart() + ", getRowCount()="
				+ getRowCount() + "]";
	}

	
}
