package com.st.ssm.order.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.order.mapper.OrderMapper;
import com.st.ssm.order.model.OrderModel;
import com.st.ssm.order.service.IOrderService;
import com.st.ssm.user.model.UserModel;

@Service
public class OrderServiceImpl implements IOrderService{

	@Autowired(required=false)
	public OrderMapper mapper;
	
	@Override
	public int insert(OrderModel orderModel) {
		// TODO Auto-generated method stub
		if(mapper.selectId(orderModel.getOrderCodeString())==null)
		return mapper.insert(orderModel);
		return 0;
	}

	@Override
	public int update(OrderModel orderModel) {
		// TODO Auto-generated method stub
		return mapper.update(orderModel);
	}

	@Override
	public int delete(String orderCodeString) {
		// TODO Auto-generated method stub
		return mapper.delete(orderCodeString);
	}

	@Override
	public List<OrderModel> selectList(OrderModel orderModel) {
		// TODO Auto-generated method stub
		if(orderModel.getOrderCodeString()!=null)
			orderModel.setOrderCodeString("%"+orderModel.getOrderCodeString()+"%");
		if(orderModel.getUserCodeString()!=null)
			orderModel.setUserCodeString("%"+orderModel.getUserCodeString()+"%");
		return mapper.selectAll(orderModel);
	}
	
	@Override
	public int selectCount(OrderModel orderModel) {
		// TODO Auto-generated method stub
		return mapper.selectCount(orderModel);
	}

	@Override
	public OrderModel selectId(String orderCodeString) {
		// TODO Auto-generated method stub
		if(orderCodeString==null||orderCodeString.length()==0)
			return new OrderModel();
		return mapper.selectId(orderCodeString);
	}

	@Override
	public int updateActive(OrderModel model) {
		// TODO Auto-generated method stub
		return mapper.updateActive(model);
	}

}
