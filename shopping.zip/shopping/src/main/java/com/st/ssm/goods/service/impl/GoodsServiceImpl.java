package com.st.ssm.goods.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.goods.mapper.GoodsMapper;
import com.st.ssm.goods.model.GoodsModel;
import com.st.ssm.goods.service.IGoodsService;
import com.st.ssm.kinds.model.KindsModel;

@Service
public class GoodsServiceImpl implements IGoodsService{

	@Autowired(required=false)
	public GoodsMapper mapper;
	
	@Override
	public int insert(GoodsModel goodsModel) {
		// TODO Auto-generated method stub
		if(mapper.selectId(goodsModel.getGoodsCodeString())==null)
		return mapper.insert(goodsModel);
		return 0;
	}

	@Override
	public int update(GoodsModel goodsModel) {
		// TODO Auto-generated method stub
		return mapper.update(goodsModel);
	}

	@Override
	public int delete(String goodsCodeString) {
		// TODO Auto-generated method stub
		return mapper.delete(goodsCodeString);
	}

	@Override
	public int selectCount(GoodsModel goodsModel) {
		// TODO Auto-generated method stub
		return mapper.selectCount(goodsModel);
	}
	
	@Override
	public List<GoodsModel> selectList(GoodsModel goodsModel) {
		// TODO Auto-generated method stub
		if(goodsModel.getGoodsNameString()!=null)
		goodsModel.setGoodsNameString("%"+goodsModel.getGoodsNameString()+"%");
		if(goodsModel.getGoodsCodeString()!=null)
			goodsModel.setGoodsCodeString("%"+goodsModel.getGoodsCodeString()+"%");
		return mapper.selectAll(goodsModel);
	}

	@Override
	public GoodsModel selectId(String goodsCodeString) {
		// TODO Auto-generated method stub
		if(goodsCodeString==null||goodsCodeString.length()==0)
			return new GoodsModel();
		return mapper.selectId(goodsCodeString);
	}

}
