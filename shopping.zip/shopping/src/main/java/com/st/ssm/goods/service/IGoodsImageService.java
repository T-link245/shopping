package com.st.ssm.goods.service;

import java.util.List;

import com.st.ssm.goods.model.GoodsImageModel;

public interface IGoodsImageService {

	int insert(GoodsImageModel goodsImageModel);

	int update(GoodsImageModel goodsImageModel);

	int delete(Integer id);

	int selectCount(GoodsImageModel goodsImageModel);

	List<GoodsImageModel> selectList(GoodsImageModel goodsImageModel);

	GoodsImageModel selectId(Integer id);

	int updateActive(GoodsImageModel goodsImageModel);

}
