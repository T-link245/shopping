package com.st.ssm.util;

public class PubPage {
	private int pageIndex=1;
	private int pageLimit=10;
	private int rowStart;
	private int rowCount;
	private boolean pageOn = false;
	private String orserby;
	private Integer count;
	
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public int getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}
	public int getPageLimit() {
		return pageLimit;
	}
	public void setPageLimit(int pageLimit) {
		this.pageLimit = pageLimit;
	}
	public int getRowStart() {
		rowStart =(pageIndex-1)*pageLimit;
		return rowStart;
	}
	public void setRowStart(int rowStart) {
		this.rowStart = rowStart;
	}
	public int getRowCount() {
		return rowCount;
	}
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	public boolean isPageOn() {
		return pageOn;
	}
	public void setPageOn(boolean pageOn) {
		this.pageOn = pageOn;
	}
	public String getOrserby() {
		return orserby;
	}
	public void setOrserby(String orserby) {
		this.orserby = orserby;
	}
	
}
