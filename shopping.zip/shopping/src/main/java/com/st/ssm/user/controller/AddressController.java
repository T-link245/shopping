package com.st.ssm.user.controller;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.st.ssm.order.model.OrderModel;
import com.st.ssm.user.model.AddressModel;
import com.st.ssm.user.service.IAddressService;

@Controller
@RequestMapping("/address")
public class AddressController {

		@Autowired
		private IAddressService addressService;
		
		@ResponseBody
		@RequestMapping(value = "/insert",produces = "application/json; charset=utf-8")
		public String insert(AddressModel addressModel) {
			int res = addressService.insert(addressModel);
			return String.valueOf(res);
		}
		
		@ResponseBody
		@RequestMapping(value = "/selectByUser",produces = "application/json; charset=utf-8")
		public String selectByUser(AddressModel addressModel) {
			List<AddressModel> list =new ArrayList<AddressModel>();
			list = addressService.selectList(addressModel);

			JSONArray jsonArray = new JSONArray();
			for (AddressModel model2 : list) {
				JSONObject object =new JSONObject();
				object.put("addressString", model2.getAddressString());
				jsonArray.put(object);
			}
			return jsonArray.toString();
		}
}
