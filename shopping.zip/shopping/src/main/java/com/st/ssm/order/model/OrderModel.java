package com.st.ssm.order.model;

import com.st.ssm.util.PubPage;

public class OrderModel extends PubPage{

	private String orderCodeString;
	private String userCodeString;
	private String addressString;
    private String orderTimeString;
	//总价
	private String sumPriceString;
	private String isPaymentString;
	
	public String getIsPaymentString() {
		return isPaymentString;
	}
	public void setIsPaymentString(String isPaymentString) {
		this.isPaymentString = isPaymentString;
	}
	public String getOrderTimeString() {
		return orderTimeString;
	}
	public void setOrderTimeString(String orderTimeString) {
		this.orderTimeString = orderTimeString;
	}
	public String getOrderCodeString() {
		return orderCodeString;
	}
	public void setOrderCodeString(String orderCodeString) {
		this.orderCodeString = orderCodeString;
	}
	public String getUserCodeString() {
		return userCodeString;
	}
	public void setUserCodeString(String userCodeString) {
		this.userCodeString = userCodeString;
	}
	public String getAddressString() {
		return addressString;
	}
	public void setAddressString(String addressString) {
		this.addressString = addressString;
	}
	public String getSumPriceString() {
		return sumPriceString;
	}
	public void setSumPriceString(String sumPriceString) {
		this.sumPriceString = sumPriceString;
	}
	public OrderModel(String orderCodeString, String userCodeString, String addressString, String orderTimeString,
			String sumPriceString, String isPaymentString) {
		super();
		this.orderCodeString = orderCodeString;
		this.userCodeString = userCodeString;
		this.addressString = addressString;
		this.orderTimeString = orderTimeString;
		this.sumPriceString = sumPriceString;
		this.isPaymentString = isPaymentString;
	}
	public OrderModel() {
		super();
	}
	
}
