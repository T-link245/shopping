package com.st.ssm.order.mapper;

import java.util.List;

import com.st.ssm.order.model.OrderDetailModel;

public interface OrderDetailMapper {
	int insert(OrderDetailModel t);
	
	int delete(Object id);
	
	int update(OrderDetailModel t);
	
	int updateActive(OrderDetailModel t);
	
	OrderDetailModel selectId(Object id);
	
	List<OrderDetailModel> selectAll(OrderDetailModel t);
	
	int selectCount(OrderDetailModel t);

	int deleteModel(OrderDetailModel orderDetailModel);
}
