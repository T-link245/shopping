package com.st.ssm.shoppingcur.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.goods.model.GoodsModel;
import com.st.ssm.shoppingcur.mapper.ShoppingCurMapper;
import com.st.ssm.shoppingcur.model.ShoppingCurModel;
import com.st.ssm.shoppingcur.service.IShoppingCurService;

@Service
public class ShoppingCurServiceImpl implements IShoppingCurService{

	@Autowired(required=false)
	public ShoppingCurMapper mapper;

		@Override
		public int insert(ShoppingCurModel t) {
			// TODO Auto-generated method stub
			return mapper.insert(t);
		}
		
		@Override
		public int delete(Integer id) {
			// TODO Auto-generated method stub
			return mapper.delete(id);
		}

		@Override
		public int update(ShoppingCurModel t) {
			// TODO Auto-generated method stub
			return mapper.update(t);
		}

		@Override
		public List<ShoppingCurModel> selectList(String userCodeString) {
			// TODO Auto-generated method stub
			ShoppingCurModel shoppingCurModel =new ShoppingCurModel();
			shoppingCurModel.setUserCodeString(userCodeString);
			return mapper.selectAll(shoppingCurModel);
		}

		@Override
		public int selectCount(ShoppingCurModel shoppingCurModel) {
			// TODO Auto-generated method stub
			return mapper.selectCount(shoppingCurModel);
		}

		@Override
		public ShoppingCurModel selectById(Integer id) {
			// TODO Auto-generated method stub
			return mapper.selectId(id);
		}

		@Override
		public ShoppingCurModel selectModel(ShoppingCurModel shoppingCurModel) {
			// TODO Auto-generated method stub
			List<ShoppingCurModel> list = mapper.selectAll(shoppingCurModel);
			if(list.size()!=0)
			return list.get(0);
			return null;
		}

}
