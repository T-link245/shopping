package com.st.ssm.order.mapper;

import java.util.List;

import com.st.ssm.order.model.OrderModel;

public interface OrderMapper {
	int insert(OrderModel t);
	
	int delete(Object id);
	
	int update(OrderModel t);
	
	int updateActive(OrderModel t);
	
	OrderModel selectId(Object id);
	
	List<OrderModel> selectAll(OrderModel t);
	
	int selectCount(OrderModel t);
}
