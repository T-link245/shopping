package com.st.ssm.goods.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ssm.goods.mapper.GoodsImageMapper;
import com.st.ssm.goods.model.GoodsImageModel;
import com.st.ssm.goods.service.IGoodsImageService;

@Service
public class GoodsImageServiceImpl implements IGoodsImageService{

	@Autowired(required=false)
	public GoodsImageMapper mapper;
	
	@Override
	public int insert(GoodsImageModel goodsImageModel) {
		// TODO Auto-generated method stub
		return mapper.insert(goodsImageModel);
	}

	@Override
	public int update(GoodsImageModel goodsImageModel) {
		// TODO Auto-generated method stub
		return mapper.update(goodsImageModel);
	}

	@Override
	public int delete(Integer id) {
		// TODO Auto-generated method stub
		return mapper.delete(id);
	}

	@Override
	public int selectCount(GoodsImageModel goodsImageModel) {
		// TODO Auto-generated method stub
		return mapper.selectCount(goodsImageModel);
	}
	
	@Override
	public List<GoodsImageModel> selectList(GoodsImageModel goodsImageModel) {
		// TODO Auto-generated method stub
		if(goodsImageModel.getGoodsCodeString()!=null)
			goodsImageModel.setGoodsCodeString("%"+goodsImageModel.getGoodsCodeString()+"%");
		return mapper.selectAll(goodsImageModel);
	}

	@Override
	public GoodsImageModel selectId(Integer id) {
		// TODO Auto-generated method stub
		return mapper.selectId(id);
	}

	@Override
	public int updateActive(GoodsImageModel goodsImageModel) {
		// TODO Auto-generated method stub
		return mapper.updateActive(goodsImageModel);
	}

}
