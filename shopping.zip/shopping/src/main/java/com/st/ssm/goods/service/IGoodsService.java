package com.st.ssm.goods.service;

import java.util.List;

import com.st.ssm.goods.model.GoodsModel;

public interface IGoodsService {
	int insert(GoodsModel goodsModel);

	int update(GoodsModel goodsModel);

	List<GoodsModel> selectList(GoodsModel goodsModel);

	GoodsModel selectId(String goodsCodeString);

	int delete(String code);

	int selectCount(GoodsModel goodsModel);

}
